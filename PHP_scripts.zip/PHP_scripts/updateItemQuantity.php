<?php
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: *");
	include 'connection.php';
    
    $iid = $_POST['itemID'];
    $lid = $_POST['labIDFrom'];
    $quantity = $_POST['qt'];


    $queryResult = "UPDATE items SET items.quantity=$quantity WHERE items.ItemID=$iid AND items.LabID=$lid;";


    
    if ($connect->query($queryResult) !== FALSE) {
        echo ('Success');
    } else {
        echo ('Failed');
    }
    
?>