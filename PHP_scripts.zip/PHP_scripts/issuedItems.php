<?php
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: *");
	include 'connection.php';
	
	$sid = $_POST['ID'];

	$queryResult = ("SELECT itemname.name, labs.Name, issueditems.Quantity, issueditems.issuedDate, issueditems.renewalDate
	            FROM itemname, labs, issueditems 
	            WHERE itemname.ItemID=issueditems.ItemID and 
	            labs.LabID=issueditems.LabID and 
	            issueditems.IssuedToID = $sid");
    
    $stm = $connect->prepare($queryResult);
    $stm->execute();
    $row = $stm->setFetchMode(PDO::FETCH_ASSOC);
    
   $stm = $connect->prepare($queryResult);
    $stm->execute();
    $row = $stm->setFetchMode(PDO::FETCH_ASSOC);
    
    $result = [];
    foreach(new RecursiveArrayIterator($stm->fetchAll()) as $k) {
        $result[] = $k;
    }
	echo json_encode($result);
	
?>