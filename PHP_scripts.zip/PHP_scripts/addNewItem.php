<?php
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: *");
	include 'connection.php';
    
    $iid = $_POST['itemID'];
    $lid = $_POST['labIDFrom'];
    $quantity = $_POST['qt'];
    $itemName = $_POST['name'];


    $updateQuery = "INSERT INTO itemname(ItemID,name) VALUES ($iid,'$itemName');";

    $firstAnswer = $connect->query($updateQuery);

    
    if ($firstAnswer !== FALSE){
        $queryResult = "INSERT INTO items(ItemID,LabID,quantity) VALUES ($iid,$lid,$quantity);";
        $secondAnswer = $connect->query($queryResult);
        if($secondAnswer !== FALSE){
         echo ('Success');   
        } else {
            echo ('Failed');
        }
    } else {
        echo ('Failed');
    }
    
?>