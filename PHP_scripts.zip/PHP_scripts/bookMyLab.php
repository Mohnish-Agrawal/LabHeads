<?php
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: *");
	include 'connection.php';
	
	$userID = $_POST['userid'];
	$labID = $_POST['labID'];
	$date = $_POST['date'];
	$time = $_POST['start_time'];
	$time2 = $_POST['end_time'];
	
    $sql = "INSERT INTO labbookings VALUES ('$labID', '$date', '$time', '$time2', '$userID')";
    
    if ($connect->query($sql) !== FALSE) {
        echo ('Success');
    } else {
        echo ('Failed');
    }
?>