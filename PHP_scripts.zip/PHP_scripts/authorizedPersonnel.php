<?php
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: *");
	include 'connection.php';
    
    
    $queryResult = "SELECT accesstolabs.ID, authorizedpersonnel.Name, accesstolabs.LabID, authorizedpersonnel.Designation FROM accesstolabs, authorizedpersonnel WHERE accesstolabs.ID=authorizedpersonnel.ID ";
  
    $stm = $connect->prepare($queryResult);
    $stm->execute();
    $row = $stm->setFetchMode(PDO::FETCH_ASSOC);
    
    $result = [];
    foreach(new RecursiveArrayIterator($stm->fetchAll()) as $k) {
        $result[] = $k;
    }
	echo json_encode($result);
?>