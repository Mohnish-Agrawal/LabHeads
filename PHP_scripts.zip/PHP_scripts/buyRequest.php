<?php
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: *");
	include 'connection.php';
	
	$item = $_POST['item'];
	$quan = $_POST['quantity'];
	$lab = $_POST['labID'];
	$cost = $_POST['cost'];
	
    $sql = "INSERT INTO ItemsToBeBought VALUES ('$lab', '$quan', '$cost', '$item')";
    
    if ($connect->query($sql) !== FALSE) {
        echo ('Success');
    } else {
        echo ('Failed');
    }
?>