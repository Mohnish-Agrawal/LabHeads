<?php
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: *");
	include 'connection.php';
    
    
    $sid = $_POST['labID'];
    
    $queryResult = "SELECT * FROM labbookingrequests WHERE labID=$sid;";
  
    $stm = $connect->prepare($queryResult);
    $stm->execute();
    $row = $stm->setFetchMode(PDO::FETCH_ASSOC);
    
    $result = [];
    foreach(new RecursiveArrayIterator($stm->fetchAll()) as $k) {
        $result[] = $k;
    }
	echo json_encode($result);
?>