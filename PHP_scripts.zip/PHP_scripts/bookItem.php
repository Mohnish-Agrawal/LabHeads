<?php
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: *");
	include 'connection.php';
    
    $iid = $_POST['itemID'];
    $lid = $_POST['labIDFrom'];
    $issue_to = $_POST['issuedtoID'];
    $quantity = $_POST['qt'];
    $tpe = "S";

    if(strlen($issue_to)==7){
        $tpe = "S";
    }elseif (strlen($issue_to)==6){
        $tpe = "P";
    }
    elseif(strcmp(substr($issue_to,0,1),"5")==0){
        $tpe = "L";
    }else{
        $tpe = "C";
    }

    $issueDate = date('Y-m-d');
    $date=strtotime(date('Y-m-d'));
    $renewal = date('Y-m-d',strtotime('+15 days',$date));

    $queryResult = "INSERT INTO issueditems(ItemID,LabID,issuedDate,renewalDate,IssuedToID,IssuedTo,Quantity) VALUES ($iid,$lid,'$issueDate','$renewal',$issue_to,'$tpe',$quantity);";

    $updateQuery = "UPDATE items SET quantity=quantity-$quantity WHERE ItemID = $iid and LabID = $lid;";
  
    //$stm = $connect->prepare($queryResult);
    //$stm->execute();
    //$row = $stm->setFetchMode(PDO::FETCH_ASSOC);

    //$utm = $connect->prepare($updateQuery);
    //$utm->execute();
    //$row2 = $utm->setFetchMode(PDO::FETCH_ASSOC);

    
    if (($connect->query($queryResult) !== FALSE) && ($connect->query($updateQuery) !== FALSE)) {
        echo ('Success');
    } else {
        echo ('Failed');
    }
    
    //$result = [];
    //foreach(new RecursiveArrayIterator($stm->fetchAll()) as $k) {
    //    $result[] = $k;
    //}
	//echo json_encode($result);
?>