<?php
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: *");
	include 'connection.php';
    
    
    $queryResult = "SELECT labs.LabID, labs.Name, timings.Days, timings.Start_time, timings.End_time FROM timings INNER JOIN labs ON timings.LabID = labs.LabID";
  
    $stm = $connect->prepare($queryResult);
    $stm->execute();
    $row = $stm->setFetchMode(PDO::FETCH_ASSOC);
    
    $result = [];
    foreach(new RecursiveArrayIterator($stm->fetchAll()) as $k) {
        $result[] = $k;
    }
	echo json_encode($result);
?>