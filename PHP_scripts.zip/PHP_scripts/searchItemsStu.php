<?php
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: *");
	include 'connection.php';
    
    $item = $_POST['searchQuery'];
    $lab = $_POST['lab'];

    
    $queryResult = "SELECT itemname.name, items.ItemID, items.quantity, labs.Name, labs.LabID FROM items INNER JOIN itemname ON itemname.ItemID=items.ItemID INNER JOIN labs ON items.LabID = labs.LabID WHERE itemname.name LIKE '%{$item}%' 
        AND labs.Name LIKE '%{$lab}%'";
  
    $stm = $connect->prepare($queryResult);
    $stm->execute();
    $row = $stm->setFetchMode(PDO::FETCH_ASSOC);
    
    $result = [];
    foreach(new RecursiveArrayIterator($stm->fetchAll()) as $k) {
        $result[] = $k;
    }
	echo json_encode($result);
?>