<?php
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: *");
	include 'connection.php';
	
	$item = $_POST['itemID'];
	$lab = $_POST['labID'];
	$cond = $_POST['condition'];
	$date = $_POST['date'];
	
    $sql = "INSERT INTO DamageReport VALUES ('$item', '$cond', '$lab', '$date')";
    
    if ($connect->query($sql) !== FALSE) {
        echo ('Success');
    } else {
        echo ('Failed');
    }
?>