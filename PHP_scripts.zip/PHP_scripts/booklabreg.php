<?php
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: *");
	include 'connection.php';
	
	$userID = $_POST['userid'];
	$labID = $_POST['labID'];
	$date = $_POST['date'];
	$time = $_POST['start_time'];
	$time2 = $_POST['end_time'];
	
    
    $sql = "INSERT INTO labbookingrequests  (userID, labID,date, start_time, end_time) SELECT $userID, $labID, '$date','$time', '$time2' from dual WHERE NOT EXISTS( SELECT * FROM labbookings WHERE '$time' BETWEEN Start_time AND End_time OR '$time2' BETWEEN Start_time AND End_time AND Date = '$date');";
    
    if ($connect->query($sql) != FALSE) {
        echo ('Success');
    } else {
        echo ('Failed');
    }
?>