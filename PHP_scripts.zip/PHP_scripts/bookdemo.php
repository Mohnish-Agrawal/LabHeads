<?php
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: *");
	include 'connection.php';
	
	// $userID = $_POST['userid'];
	// $labID = $_POST['labID'];
	// $date = $_POST['date'];
	// $time = $_POST['start_time'];
	// $time2 = $_POST['end_time'];
	
    $userID = 201;
    $labID = 511;
    $date = "2020-04-25";
    $time = "09:00:00";
    $time2 = "10:00:00";
    
    $sql = "INSERT INTO labbookingrequests  (userID, labID,date, start_time, end_time) SELECT $userID, $labID, '$date','$time', '$time2' from dual WHERE NOT EXISTS( SELECT * FROM labbookings WHERE '$time' BETWEEN Start_time AND End_time OR '$time2' BETWEEN Start_time AND End_time AND Date = '$date')";
    echo ($sql);
    $connect->query($sql);
?>