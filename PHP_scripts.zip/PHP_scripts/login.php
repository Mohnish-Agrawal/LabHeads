<?php
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: *");
	include 'connection.php';
	
	$userf = $_POST['username'];
	$passf = $_POST['password'];
    // $userf = "ST18001";
    // $passf = "Mohnish";


                    
    $queryResult ="SELECT userdetails.Type, (CASE WHEN userdetails.Type='LabManagers' THEN accesstolabs.LabID ELSE userdetails.UserID END) AS UserID, userdetails.Name, userdetails.Username, userdetails.Password FROM userdetails LEFT JOIN accesstolabs ON userdetails.UserID=accesstolabs.ID WHERE userdetails.Username = '$userf' AND userdetails.Password = '$passf';";
                    
	//OLD QUERY $queryResult = ("SELECT Type, UserID, Name from userdetails WHERE Username = '$userf' AND Password = '$passf'");
    // $queryResult = ("SELECT * from UserDetails");
    
    $stm = $connect->prepare($queryResult);
    $stm->execute();
    $row = $stm->setFetchMode(PDO::FETCH_ASSOC);
    
    $result = [];
    foreach(new RecursiveArrayIterator($stm->fetchAll()) as $k) {
        $result[] = $k;
    }
	echo json_encode($result);
	
?>