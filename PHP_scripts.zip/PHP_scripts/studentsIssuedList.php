<?php
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: *");
	include 'connection.php';
	
	$sid = $_POST['ID'];
	
    $queryResult = "SELECT issueditems.IssuedToID, issueditems.IssuedTo, (CASE 
                WHEN issueditems.IssuedTo='S' THEN students.Name 
                WHEN issueditems.IssuedTo='L' THEN labs.Name 
                WHEN issueditems.IssuedTo='C' THEN clubs.ClubName
                WHEN issueditems.IssuedTo='P' THEN instructors.InstructorName
                END) 
                AS Name, itemname.name, issueditems.Quantity, issueditems.issuedDate, issueditems.renewalDate FROM 
                issueditems LEFT JOIN students ON issueditems.IssuedToID=students.StudentID 
                LEFT JOIN labs ON issueditems.IssuedToID=labs.LabID 
                LEFT JOIN clubs ON issueditems.IssuedToID=clubs.ClubID
                LEFT JOIN instructors ON issueditems.IssuedToID=instructors.InstructorID
                INNER JOIN itemname ON itemname.ItemID = issueditems.ItemID where issueditems.LabID = $sid AND issueditems.isItemReturned=0";
     
    $stm = $connect->prepare($queryResult);
    $stm->execute();
    $row = $stm->setFetchMode(PDO::FETCH_ASSOC);
    
    $result = [];
    foreach(new RecursiveArrayIterator($stm->fetchAll()) as $k) {
        $result[] = $k;
    }
	echo json_encode($result);
?>