<?php

	$dns = 'mysql:host=localhost;dbname=id13273953_labmanagement';
	$user = 'id13273953_labheads5';
	$password = '&%qM1*2jN2@R%L$y';

	try{
		$connect = new PDO ($dns, $user, $password);
	}catch( PDOException $e){
		$error = $e->getMessage();
		echo $error;
	}

?>

